UCI HAR sample upload files

Each CSV/XLSX contains a true_label column and 561 numeric features per row.
The datasets contain balanced activity classes sampled from the official UCI HAR
test partition. Use one file at a time and choose Compare both models in the web app.
Raw sensor CSVs such as TotalAcceleration.csv are not these model features.

Source: UCI Machine Learning Repository, Human Activity Recognition Using
Smartphones (UCI HAR Dataset), https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones
License: Creative Commons Attribution 4.0 International (CC BY 4.0).
