UCI HAR sample upload files

Each CSV/XLSX contains a true_label column and 561 numeric features per row.
The 120-, 300-, and 600-row datasets are balanced across six activities (20,
50, and 100 rows per activity respectively). They are sampled from the official
UCI HAR test partition and are intended for upload/prediction demonstrations.
Use one file at a time and choose "Compare both models" in the web app.
Raw sensor CSVs such as TotalAcceleration.csv are not these model features.

Source: UCI Machine Learning Repository, Human Activity Recognition Using
Smartphones (UCI HAR Dataset), https://archive.ics.uci.edu/dataset/240/human+activity+recognition+using+smartphones
License: Creative Commons Attribution 4.0 International (CC BY 4.0).
